# SPDX-License-Identifier: GPL-2.0
# Copyright (C) 2020-present Team LibreELEC

import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), 'resources', 'lib'))
sys.path.append(os.path.join(os.path.dirname(__file__), 'resources', 'lib', 'modules'))
