
import xbmcgui

from src.services import lbrynet


p_open = lbrynet.start()
xbmcgui.Dialog().notification("LbryAPI", "Starting background server", xbmcgui.NOTIFICATION_INFO)
