#Kodi plugin for RSS feeds

This is a basic plugin for accessing RSS .xml content (video's only, for now).

By default you don't need to install any extra software to start using this plugin, but it
relies on the script.module.feedparser to work and a you need to insert an url of the type
https://www.website.com/rssvideofeed.xml in the settings.

