#Kodi plugin for RSS feeds

This is a basic plugin for accessing RSS .xml video content.

By default you don't need to install any extra software to start using this plugin, but it
relies on the script.module.feedparser to work and a you need to insert an url of the type
https://www.website.com/rssvideofeed.xml in the settings.

feedparser reference:-  https://feedparser.readthedocs.io/en/latest/reference.html
