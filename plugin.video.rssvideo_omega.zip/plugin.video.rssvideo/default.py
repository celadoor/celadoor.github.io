# -*- coding: cp1252 -*-
import xbmcplugin,xbmcgui,xbmcaddon
import feedparser
#RSS Video plugin 2024

addon         = xbmcaddon.Addon('plugin.video.rssvideo')
__language__  = addon.getLocalizedString
icon = addon.getAddonInfo('icon')
fanart = addon.getAddonInfo('fanart')
items_per_page = addon.getSettingInt('items_per_page')
RSS_url1 = addon.getSetting('RSS_url1')
RSS_url2 = addon.getSetting('RSS_url2')
RSS_url3 = addon.getSetting('RSS_url3')
RSS_url4 = addon.getSetting('RSS_url4')

def INDEX():
        d = feedparser.parse(RSS_url1)
        #if 'title' in d.feed:
        studio = d.feed.title
        #else:
        genre = d.feed.subtitle 
        icon = d.feed.image.href
        for row in range(0, items_per_page):
            name = d.entries[row].title
            url = d.entries[row].link
            description = d.entries[row].description
            published = d.entries[row].published
            addLink(name,url,icon,description,published,genre,studio)

def addLink(name,url,icon,description,published,genre,studio):
        ok=True
        liz=xbmcgui.ListItem(name, icon)
        liz.setInfo( type="Video", infoLabels={ "Title": name , "Plot": description, "Director": studio, "Genre": genre, "Studio": published})
        liz.setArt({'icon': "DefaultFolder.png", 'thumb': icon,'fanart':icon})
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok
INDEX()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
