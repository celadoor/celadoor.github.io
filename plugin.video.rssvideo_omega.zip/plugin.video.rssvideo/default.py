# -*- coding: cp1252 -*-
import xbmcplugin,xbmcgui,xbmcaddon
import feedparser
#RSS Video plugin 2024

addon         = xbmcaddon.Addon('plugin.video.rssvideo')
__language__  = addon.getLocalizedString
icon = addon.getAddonInfo('icon')
fanart = addon.getAddonInfo('fanart')
items_per_page = addon.getSettingInt('items_per_page')

#url needs to be entered in settings
RSS_url1 = addon.getSetting('RSS_url1')

def Index():
        d = feedparser.parse(RSS_url1)
        if 'title' in d.feed:
                director = d.feed.title
        else:
                director = "_"
        if 'subtitle' in d.feed:
                genre = d.feed.subtitle
        else:
                genre = "_"
        thumb = d.feed.image.href
        for row in range(0, items_per_page):
            title = d.entries[row].title
            url = d.entries[row].link
            plot = d.entries[row].description
            studio = d.entries[row].published
            addLink(title,url,thumb,plot,studio,director,genre)

def addLink(title,url,thumb,plot,studio,director,genre):
        ok=True
        liz=xbmcgui.ListItem(title, thumb)
        liz.setInfo( type="Video", infoLabels={ "Title": title , "Plot": plot, "Studio": studio, "Director": director, "Genre": genre})
        liz.setArt({'icon': "DefaultFolder.png", 'thumb': thumb,'fanart':fanart})
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

Index()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
