# -*- coding: cp1252 -*-
from builtins import str
from builtins import range
import urllib.request, urllib.parse, urllib.error,re,xbmcplugin,xbmcgui
import xbmcaddon
import sys
import feedparser

#CorbettReport plugin 2013

addon         = xbmcaddon.Addon('plugin.video.corbettreport')
__language__  = addon.getLocalizedString
__icon__ = addon.getAddonInfo('icon')
__fanart__ = addon.getAddonInfo('fanart')

latest = 'special://home/addons/plugin.video.corbettreport/resources/assets/icon.png'
podcast = 'special://home/addons/plugin.video.corbettreport/resources/assets/podcastlogoitunes.jpg'
radio = 'special://home/addons/plugin.video.corbettreport/resources/assets/radiologo.jpg'
best = 'special://home/addons/plugin.video.corbettreport/resources/assets/best.jpg'

RSS_url1 = addon.getSetting('RSS_url1')
RSS_url2 = addon.getSetting('RSS_url2')
RSS_url3 = addon.getSetting('RSS_url3')
items_per_page = addon.getSettingInt('items_per_page')


def CATEGORIES():
        studio = __language__(30017)
        addDir(__language__(30016)+studio,"1",1,latest,__language__(30018),studio)
        addDir(__language__(30014),"2",1,podcast,__language__(30018),studio)
        addDir(__language__(30015),"3",1,radio,__language__(30018),studio)
        addDir(__language__(30023),'https://www.corbettreport.com/bestof/',2,best,__language__(30018),__language__(30023))
                      
def INDEX1(url):
        if url == "1":
            chosen = feedparser.parse(RSS_url1)
        elif url == "2":
            chosen = feedparser.parse(RSS_url2)
        else: 
            chosen = feedparser.parse(RSS_url3)
        page = 0
        studio = chosen.feed.title
        genre = chosen.feed.subtitle
        icon = chosen.feed.image.href
        for row in range(0, items_per_page):
            name = chosen.entries[row].title
            url = chosen.entries[row].link
            description = chosen.entries[row].description
            published = chosen.entries[row].published
            addLink(name,url,icon,description,published,genre,studio)
            page = page + 1
            if page >= items_per_page: break
        else:
            xbmc.log(__language__(30021), xbmc.LOGERROR )
            xbmcgui.Dialog().ok(__language__(30022), __language__(30021))

def INDEX2(url):
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib.request.urlopen(req)
        link = response.read().decode("utf-8")
        response.close()
        #the rest
        match=re.compile('<p><a href="(.+?)" target="_blank" rel="noopener noreferrer">(.+?)</a>').findall(link)
        if len(match) > 0:
               for url,name in match:
                      name = name.replace('&#039;', '"').replace('&#8211;', '"').replace('&#8217;', ' ').replace('&amp;', '&').replace('&#8210;', "'").replace('&#8220;', "'").replace('&#8221;', "'") .replace('&quot;', '"') # Cleanup the title.
                      addDir(name,url,3,best,name+__language__(30019)+__language__(30020),__language__(30023))
        else:
                xbmc.log(__language__(30021), xbmc.LOGERROR )
                xbmcgui.Dialog().ok(__language__(30022), __language__(30021))


def VIDEOLINKS3(url,name):
        item = 0
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib.request.urlopen(req)
        #link=response.read()
        link = response.read().decode("utf-8")
        response.close()
        match=re.compile('://www.corbettreport.com/mp4(.+?)"').findall(link)
        if len(match) > 0:
               for url in match:
                      addLink(name,'https://www.corbettreport.com/mp4'+url,__fanart__,__language__(30020),name,__language__(30023),__language__(30017))
                      item = item + 1
                      if item > 1: break
        else:
                xbmc.log(__language__(30021), xbmc.LOGERROR )
                xbmcgui.Dialog().ok(__language__(30022), __language__(30021))

             
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,icon,description,published,genre,studio):
        ok=True
        liz=xbmcgui.ListItem(name, icon)
        liz.setInfo( type="Video", infoLabels={ "Title": name , "Plot": description, "Director": studio, "Genre": genre, "Studio": published})
        liz.setArt({'icon': "DefaultFolder.png", 'thumb': icon,'fanart':icon})
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addDir(name,url,mode,icon,description,genre):
        u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, icon)
        liz.setInfo( type="Video", infoLabels={ "Title": name , "Plot": description, "Genre": genre, "Studio": __language__(30017)} )
        liz.setArt({'icon': "DefaultFolder.png", 'thumb': icon,'fanart':icon})
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
       
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print("Mode: "+str(mode))
print("URL: "+str(url))
print("Name: "+str(name))

if mode==None or url==None or len(url)<1:
        print("")
        CATEGORIES()
       
elif mode==1:
        print(""+url)
        INDEX1(url)

elif mode==2:
        print(""+url)
        INDEX2(url)
        
elif mode==3:
        print(""+url)
        VIDEOLINKS3(url,name)
else:
        print(""+url)
        CATEGORIES()


xbmcplugin.endOfDirectory(int(sys.argv[1]))
