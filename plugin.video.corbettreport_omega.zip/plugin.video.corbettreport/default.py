# -*- coding: cp1252 -*-
from __future__ import print_function
from future import standard_library
standard_library.install_aliases()
from builtins import str
from builtins import range
import urllib.request, urllib.parse, urllib.error,urllib.request,urllib.error,urllib.parse,re,xbmcplugin,xbmcgui
import xbmcaddon
import sys

#CorbettReport plugin 2013

addon         = xbmcaddon.Addon('plugin.video.corbettreport')
__language__  = addon.getLocalizedString
__icon__ = addon.getAddonInfo('icon')
__fanart__ = addon.getAddonInfo('fanart')
best = 'special://home/addons/plugin.video.corbettreport/resources/best.jpg'
icon = 'special://home/addons/plugin.video.corbettreport/resources/icon.png'



def CATEGORIES():
        addDir(__language__(30011),'https://www.corbettreport.com/category/videos/',1,icon,__language__(30018))
        addDir(__language__(30023),'https://www.corbettreport.com/bestof/',2,best,__language__(30018))
                       
def INDEX1(url):
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib.request.urlopen(req)
        link = response.read().decode("utf-8")
        response.close()
        #the rest
        #match=re.compile('<option value="(.+?)">(.+?)</option><option value').findall(link)
        match=re.compile('<option value="(.+?)">(.+?)</option>').findall(link)
        if len(match) > 0:
               for url,name in match:
                      name = name.replace('&#039;', '"').replace('&#8211;', '"').replace('&#8217;', ' ').replace('&amp;', '&').replace('&#8210;', "'").replace('&#8220;', "'").replace('&#8221;', "'").replace('&quot;', '"')  # Cleanup the title.
                      addDir(name,url,3,icon,name+__language__(30019)+__language__(30020))
        else:
                xbmc.log(__language__(30021), xbmc.LOGERROR )
                xbmcgui.Dialog().ok(__language__(30022), __language__(30021))

def INDEX2(url):
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib.request.urlopen(req)
        link = response.read().decode("utf-8")
        response.close()
        #the rest
        match=re.compile('<p><a href="(.+?)" target="_blank" rel="noopener noreferrer">(.+?)</a>').findall(link)
        if len(match) > 0:
               for url,name in match:
                      name = name.replace('&#039;', '"').replace('&#8211;', '"').replace('&#8217;', ' ').replace('&amp;', '&').replace('&#8210;', "'").replace('&#8220;', "'").replace('&#8221;', "'") .replace('&quot;', '"') # Cleanup the title.
                      addDir(name,url,3,best,name+__language__(30019)+__language__(30020))
        else:
                xbmc.log(__language__(30021), xbmc.LOGERROR )
                xbmcgui.Dialog().ok(__language__(30022), __language__(30021))



def VIDEOLINKS3(url,name):
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib.request.urlopen(req)
        #link=response.read()
        link = response.read().decode("utf-8")
        response.close()
        match=re.compile('://www.corbettreport.com/mp4(.+?)"').findall(link)
        for url in match:
                addLink(name,'http://www.corbettreport.com/mp4'+url,__fanart__)
                break

                
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,icon):
        ok=True
        liz=xbmcgui.ListItem(name, icon)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setArt({'icon': "DefaultFolder.png", 'thumb': icon})
        #player = xbmc.Player()
        #player.play(url, liz);
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,icon,description):
        u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, icon)
        liz.setInfo( type="Video", infoLabels={ "Title": name , "Plot": description, "Genre": "Video", "Studio": "The Corbett Report"} )
        liz.setArt({'icon': "DefaultFolder.png", 'thumb': icon,'fanart':icon})
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
       
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print("Mode: "+str(mode))
print("URL: "+str(url))
print("Name: "+str(name))

if mode==None or url==None or len(url)<1:
        print("")
        CATEGORIES()
       
elif mode==1:
        print(""+url)
        INDEX1(url)

elif mode==2:
        print(""+url)
        INDEX2(url)
        
elif mode==3:
        print(""+url)
        VIDEOLINKS3(url,name)
else:
        print(""+url)
        CATEGORIES()


xbmcplugin.endOfDirectory(int(sys.argv[1]))
