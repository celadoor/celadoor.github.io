# -*- coding: cp1252 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui
import xbmcaddon
import sys
# Set default encoding to 'UTF-8' instead of 'ascii'
reload(sys)
sys.setdefaultencoding("UTF8")

#tagen.tv plugin

addon         = xbmcaddon.Addon('plugin.video.tagen.tv')
__language__  = addon.getLocalizedString
__icon__ = addon.getAddonInfo('icon')



def CATEGORIES():
        addDir('Tagen Tv Videos','http://tagen.tv/vod/tag/',1,__icon__,'Tagen Tv Videos')
        addDir('Tagen Tv-Krzysztof Jackowski','http://tagen.tv/vod/tag/krzysztof-jackowski/',2,__icon__,'Tagen Tv-Krzysztof Jackowski')
        addLink('Tagen Tv Live Stream','rtmp://213.189.53.89:80/live/ playpath=glowna swfUrl="http://p.jwpcdn.com/6/12/jwplayer.flash.swf" pageUrl="http://tagen.tv/" swfVfy=true live=true',__icon__,'Live Stream')
        addDir('Planner Tagen Tv','http://tagen.tv',1,__icon__,'Planner Tagen Tv')

                     
def INDEX(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        #the rest
        match=re.compile('href="/vod/tag/(.+?)/"').findall(link)
        if len(match) > 0:
               for url in match:
                      formattedname = url.replace("-"," ").title()
                      addDir(formattedname,'http://tagen.tv/vod/tag/'+url,2,__icon__,url)
        else:
                xbmc.log(__language__(30021), xbmc.LOGERROR )
                xbmcgui.Dialog().ok(__language__(30022), __language__(30021))
        

def INDEX2(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        #the rest
        match=re.compile('<a href="/vod(.+?)#').findall(link)#ALL Videos
        if len(match) > 0:
               for url in match:
                      addLink(url[1:-1].replace("-"," ").replace("/","-"),'rtmp://213.189.53.89:80/vod/ playpath=mp4:vod'+url[:-1]+'.mp4 swfUrl="http://p.jwpcdn.com/6/12/jwplayer.flash.swf" pageUrl="http://tagen.tv/vod'+url+'"',__icon__,url)
        else:
                xbmc.log(__language__(30021), xbmc.LOGERROR )
                xbmcgui.Dialog().ok(__language__(30022), __language__(30021))

def VIDEOLINKS(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('_url":"(.+?)"').findall(link)
        for url in match:
                addLink(__language__(30011),url,__icon__)
        

                
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addLink(name,url,iconimage,description):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name , "Plot": description} )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name , "Plot": description} )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        print ""+url
        INDEX(url)
        

elif mode==2:
        print ""+url
        INDEX2(url)

elif mode==3:
        print ""+url
        VIDEOLINKS(url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
